Robert Roche
rr696

This README file goes over the core elements of the webpage.

Text:
The start of the page simply contains titles, headers and a breif history of the fibonacci sequence.
It also contains a link to more information on the history.

Image:
Next is an image pictured directly below the text.

Text Box and Button:
The text box allows the user to enter their desired input.
The button once clicked calls the JS function to evaluate the input.

Javascript:
	Variables:
	Multiple variables are declared to start.
	User input is taken from text box and assgined to the variable num.

	If statements:
	The if statements check to make sure the input is valid as per provided guidelines.
	Gives proper error message if not.

	Table:
	A table is created after the if statement and is grown with each iteration of the loop.
	The first column contains the position in the sequence, and the second contains the fiboncacci number.
	The table is displayed upon completion of the loop.

	For Loop:
	The loop iterates until the desired number is reached. The var3 is assigned the sum of the two previous numbers,
	the previous numbers are then incremented.