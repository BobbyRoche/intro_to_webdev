Robert Roche

rr696

CS275 Assignment 3

This is a resubmission of my original project. I submitted on Tuesday 2/19 originally, however I realized I completely forgot to add my screencast. I hope this okay that I am resubmitting and if I am to get points docced I would rather have you grade just my code and README. Sorry for the inconvience.


This program will be run via a node.js server. To run this application one must put the url http://localhost:8080/hw3 into their browser.
I used Google Chrome to test this project so thatmy be the best environment. Make sure the html file and js file are in the same directory.

The node.js file will execute the html file. This file will take in a number from the user and allow them to select factorial or summation.
After the submit button is pressedthe server will recieve a request and will take the math function name and the seed n and return the result
to the html file which will in turn print that result  the empty div.

There is various CSS involved to make this page look nicer including a background that is a white board to add a classroom theme to the page.
